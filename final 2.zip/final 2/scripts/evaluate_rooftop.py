"""Step 4b: test rooftop_yolo.onnx on roof images.
usage: python evaluate_rooftop.py --images roof_imgs [--labels roof_labels] [--classes classes.txt] [--conf 0.25]
--labels is optional (YOLO .txt files, same names). With labels you get image-level accuracy + false alarms.
Without labels you just get detection counts and annotated images in ./rooftop_out"""
import argparse, glob, os
from ultralytics import YOLO
ap = argparse.ArgumentParser()
ap.add_argument("--images", required=True); ap.add_argument("--labels"); ap.add_argument("--model", default="rooftop_yolo.onnx")
ap.add_argument("--conf", type=float, default=0.25); ap.add_argument("--classes", default="classes.txt")
a = ap.parse_args()
names = [l.split(": ",1)[1].strip() for l in open(a.classes)] if os.path.exists(a.classes) else None
m = YOLO(a.model, task="detect")
imgs = sorted(sum([glob.glob(os.path.join(a.images,e)) for e in ("*.jpg","*.jpeg","*.png")],[]))
os.makedirs("rooftop_out",exist_ok=True)
tp=fp=fn=tn=0; counts={}
for f in imgs:
    r = m.predict(f, imgsz=640, conf=a.conf, verbose=False)[0]
    r.save(os.path.join("rooftop_out",os.path.basename(f)))
    pred = set(int(c) for c in r.boxes.cls.tolist())
    for c in r.boxes.cls.tolist(): counts[int(c)] = counts.get(int(c),0)+1
    if a.labels:
        lf = os.path.join(a.labels, os.path.splitext(os.path.basename(f))[0]+".txt")
        gt = set(int(l.split()[0]) for l in open(lf)) if os.path.exists(lf) else set()
        for c in pred|gt:
            if c in pred and c in gt: tp+=1
            elif c in pred: fp+=1
            else: fn+=1
        tn += 0 if (pred|gt) else 1
print(f"\nImages: {len(imgs)}   total detections by class:", {(names[k] if names else k):v for k,v in counts.items()})
print(f"Images with at least one detection: see rooftop_out/")
if a.labels:
    print(f"Correct detections (per image per class): {tp}   False alarms: {fp}   Missed: {fn}   Clean images with no alarm: {tn}")
    print(f"Precision {100*tp/max(tp+fp,1):.1f}%   Recall {100*tp/max(tp+fn,1):.1f}%   False-alarm share of alerts {100*fp/max(tp+fp,1):.1f}%")
