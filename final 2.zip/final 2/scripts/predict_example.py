"""Reference for the backend: how the app should call both models (pure onnxruntime, no torch).
Also the logic for the 'new solar panel or pool detected' alert."""
import numpy as np, onnxruntime as ort
from PIL import Image

def load_classes(path="classes.txt"):
    return [l.split(": ",1)[1].strip() for l in open(path)]

def change_map(sess, imgA, imgB, thr=0.5):
    """imgA/imgB: PIL images. Returns boolean mask [256,256] (resize in, resize out if needed)."""
    f = lambda im: np.asarray(im.convert("RGB").resize((256,256)),np.float32).transpose(2,0,1)[None]/255.
    return sess.run(None,{"A":f(imgA),"B":f(imgB)})[0][0,0] > thr

def yolo_detect(sess, img, conf=0.25, iou=0.45, size=640):
    """Raw YOLOv8 ONNX output [1,4+nc,8400] -> list of (cls, score, x1,y1,x2,y2) in ORIGINAL pixels."""
    W,H = img.size; r = min(size/W,size/H); nw,nh = int(W*r),int(H*r)
    canvas = Image.new("RGB",(size,size),(114,114,114)); px,py=(size-nw)//2,(size-nh)//2
    canvas.paste(img.convert("RGB").resize((nw,nh)),(px,py))
    x = np.asarray(canvas,np.float32).transpose(2,0,1)[None]/255.
    out = sess.run(None,{sess.get_inputs()[0].name:x})[0][0].T          # [8400, 4+nc]
    sc = out[:,4:]; cls = sc.argmax(1); score = sc.max(1); keep = score>conf
    b,cls,score = out[keep,:4],cls[keep],score[keep]
    xyxy = np.stack([b[:,0]-b[:,2]/2,b[:,1]-b[:,3]/2,b[:,0]+b[:,2]/2,b[:,1]+b[:,3]/2],1)
    order = score.argsort()[::-1]; res=[]
    while len(order):
        i=order[0]; res.append(i)
        if len(order)==1: break
        j=order[1:]; xx1=np.maximum(xyxy[i,0],xyxy[j,0]); yy1=np.maximum(xyxy[i,1],xyxy[j,1])
        xx2=np.minimum(xyxy[i,2],xyxy[j,2]); yy2=np.minimum(xyxy[i,3],xyxy[j,3])
        inter=np.clip(xx2-xx1,0,None)*np.clip(yy2-yy1,0,None)
        ai=(xyxy[i,2]-xyxy[i,0])*(xyxy[i,3]-xyxy[i,1]); aj=(xyxy[j,2]-xyxy[j,0])*(xyxy[j,3]-xyxy[j,1])
        order=j[(inter/(ai+aj-inter+1e-9)) < iou]
    out=[]
    for i in res:
        x1,y1,x2,y2 = (xyxy[i]-[px,py,px,py])/r
        out.append((int(cls[i]),float(score[i]),float(max(x1,0)),float(max(y1,0)),float(min(x2,W)),float(min(y2,H))))
    return out

def new_addon_alert(yolo, cd, classes, before, after, addon_names=("solar","pool"), min_change_frac=0.002):
    """Alert if (a) change model sees change AND (b) after-photo has a solar/pool detection that the before-photo lacks."""
    changed = change_map(cd,before,after).mean() > min_change_frac
    cnt = lambda im: {k: sum(1 for d in yolo_detect(yolo,im) if any(a in classes[d[0]].lower() for a in [k])) for k in addon_names}
    b,a = cnt(before),cnt(after)
    new = [k for k in addon_names if a[k]>b[k]]
    return {"alert": bool(new), "new_items": new, "scene_changed": bool(changed), "before": b, "after": a}
