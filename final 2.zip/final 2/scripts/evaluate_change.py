"""Step 4a: test levir_cd.onnx on LEVIR-CD pairs.
Folder layout (standard LEVIR-CD):  root/A/*.png  root/B/*.png  root/label/*.png
Large images (1024x1024) are cut into 256x256 tiles; each tile is one test pair.
usage: python evaluate_change.py --root path/to/LEVIR-CD/test [--model levir_cd.onnx] [--thr 0.5] [--min_px 50] [--save_vis out_dir]"""
import argparse, glob, os, numpy as np, onnxruntime as ort
from PIL import Image
ap = argparse.ArgumentParser()
ap.add_argument("--root", required=True); ap.add_argument("--model", default="levir_cd.onnx")
ap.add_argument("--thr", type=float, default=0.5, help="pixel prob threshold")
ap.add_argument("--min_px", type=int, default=50, help="min changed pixels for a tile to count as 'change'")
ap.add_argument("--save_vis", default=None); ap.add_argument("--max_images", type=int, default=0)
a = ap.parse_args()
s = ort.InferenceSession(a.model, providers=["CPUExecutionProvider"])
def find(folder, name):
    stem = os.path.splitext(name)[0].lower()
    for g in glob.glob(os.path.join(a.root, folder, "*")):
        if os.path.splitext(os.path.basename(g))[0].lower() == stem: return g
    return None
all_a = sorted(glob.glob(os.path.join(a.root, "A", "*")))
files = [f for f in all_a if find("B", os.path.basename(f)) and find("label", os.path.basename(f))]
print(f"A images: {len(all_a)}, usable pairs (have B and label): {len(files)}, skipped: {len(all_a)-len(files)}")
if not files: raise SystemExit("No usable pairs: need matching names in A, B and label.")
if a.max_images: files = files[:a.max_images]
if a.save_vis: os.makedirs(a.save_vis, exist_ok=True)
tp=fp=fn=tn=0; ptp=pfp=pfn=0
def prep(im): return np.asarray(im.convert("RGB"),np.float32).transpose(2,0,1)[None]/255.
for f in files:
    n = os.path.basename(f)
    A = Image.open(f); B = Image.open(find("B", n)); L = np.asarray(Image.open(find("label", n)).convert("L"))>127
    W,H = A.size
    for y in range(0,H-255,256):
        for x in range(0,W-255,256):
            box=(x,y,x+256,y+256)
            pm = s.run(None,{"A":prep(A.crop(box)),"B":prep(B.crop(box))})[0][0,0] > a.thr
            gt = L[y:y+256,x:x+256]
            ptp+=(pm&gt).sum(); pfp+=(pm&~gt).sum(); pfn+=(~pm&gt).sum()
            g=gt.sum()>=a.min_px; p=pm.sum()>=a.min_px
            tp+=g&p; fn+=g&~p; fp+=(~g)&p; tn+=(~g)&~p
            if a.save_vis and g and p and np.random.rand()<0.05:
                vis=np.concatenate([np.asarray(A.crop(box).convert("RGB")),np.asarray(B.crop(box).convert("RGB")),np.stack([pm*255]*3,-1).astype(np.uint8)],1)
                Image.fromarray(vis).save(os.path.join(a.save_vis,f"{n[:-4]}_{x}_{y}.png"))
tot=tp+fp+fn+tn
print(f"\nTiles tested: {tot}  (with real change: {tp+fn}, without: {fp+tn})")
print(f"Change CAUGHT (recall):        {tp}/{tp+fn} = {100*tp/max(tp+fn,1):.1f}%")
print(f"Alerts that are correct (precision): {tp}/{tp+fp} = {100*tp/max(tp+fp,1):.1f}%")
print(f"FALSE ALARMS on no-change tiles: {fp}/{fp+tn} = {100*fp/max(fp+tn,1):.1f}%")
print(f"Overall tile accuracy: {100*(tp+tn)/max(tot,1):.1f}%")
P=ptp/max(ptp+pfp,1); R=ptp/max(ptp+pfn,1)
print(f"Pixel level: precision {P:.3f}  recall {R:.3f}  F1 {2*P*R/max(P+R,1e-9):.3f}  IoU {ptp/max(ptp+pfp+pfn,1):.3f}")
