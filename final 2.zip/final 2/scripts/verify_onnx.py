"""Step 3: confirm both models load and print input/output shapes.
usage: python verify_onnx.py [levir_cd.onnx] [rooftop_yolo.onnx]"""
import sys, numpy as np, onnxruntime as ort
cd = sys.argv[1] if len(sys.argv)>1 else "levir_cd.onnx"
yo = sys.argv[2] if len(sys.argv)>2 else "rooftop_yolo.onnx"
for path, feeds in [(cd, None), (yo, None)]:
    s = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
    ins = s.get_inputs(); outs = s.get_outputs()
    print(f"\n{path}")
    for i in ins:  print("  input ", i.name, i.shape, i.type)
    for o in outs: print("  output", o.name, o.shape, o.type)
    feed = {i.name: np.random.rand(*[d if isinstance(d,int) else 1 for d in i.shape]).astype(np.float32) for i in ins}
    res = s.run(None, feed)
    print("  ran OK, output shape:", res[0].shape)
cd_s = ort.InferenceSession(cd); assert [i.name for i in cd_s.get_inputs()]==["A","B"], "change model inputs must be A and B"
assert list(cd_s.run(None,{"A":np.zeros((1,3,256,256),np.float32),"B":np.zeros((1,3,256,256),np.float32)})[0].shape)==[1,1,256,256]
print("\nALL CHECKS PASSED")
