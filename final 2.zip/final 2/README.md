# Handoff: ONNX models + code

models/            levir_cd.onnx, rooftop_yolo.onnx, classes.txt  (do NOT commit to GitHub)
scripts/           verify_onnx.py, evaluate_change.py, evaluate_rooftop.py, predict_example.py
colab_notebooks/   notebooks used to build the models
RESULTS.md         model contract + test numbers

## Owner setup
Copy models/ into the project and set the three paths in backend\.env
(use the variable names the backend expects), e.g.
  CHANGE_MODEL_PATH=models\levir_cd.onnx
  ROOFTOP_MODEL_PATH=models\rooftop_yolo.onnx
  ROOFTOP_CLASSES_PATH=models\classes.txt

scripts/predict_example.py shows how to call both models with plain onnxruntime
and contains new_addon_alert(): the "new solar panel or pool detected" logic
(change model sees change AND the after photo has more solar/pool detections than the before photo).

## Quick checks
pip install onnxruntime pillow numpy ultralytics
python scripts/verify_onnx.py models/levir_cd.onnx models/rooftop_yolo.onnx
python scripts/evaluate_change.py --root <LEVIR-CD folder with A/ B/ label/> --model models/levir_cd.onnx
python scripts/evaluate_rooftop.py --images <roof images> --model models/rooftop_yolo.onnx --classes models/classes.txt
