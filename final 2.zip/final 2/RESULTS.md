# Model results

## Files (in models/)
| file | input | output |
|---|---|---|
| levir_cd.onnx | A, B: float32 [1,3,256,256], RGB scaled 0..1 | change_map: float32 [1,1,256,256], change probability (use threshold ~0.5) |
| rooftop_yolo.onnx | images: float32 [1,3,640,640], RGB 0..1, letterboxed | output0: float32 [1,6,8400] (cx,cy,w,h + 2 class scores) |

Class order (classes.txt): 0 = solar_panel, 1 = pool

Verified with onnxruntime: both load, shapes as above.

## How they were made
- levir_cd.onnx: BIT-CD (justchenhao/BIT_CD) with its pretrained LEVIR-CD checkpoint, exported at opset 17. Normalisation and softmax are inside the model.
- rooftop_yolo.onnx: YOLOv8n trained 60 epochs at 640 on merged public Roboflow aerial datasets (solar panels + swimming pools), exported at opset 17.

## Test results

### Rooftop model (rooftop_yolo.onnx)
Run in Colab on the 138-image test split of the merged aerial dataset, conf 0.25, image-level per class:
- Correct detections: 96   Missed: 4   False alarms: 5
- Precision 95.0%   Recall 96.0%   False-alarm rate 2.8%
- Caveat: the test split is mostly pool images; solar panels have few test images, so solar accuracy is less proven.
- Training-set validation metrics (P / R / mAP50 per class): ___ (copy from the end of the YOLO training output)

### Change model (levir_cd.onnx)
Run locally on the 11 usable LEVIR-CD sample pairs shipped with the BIT_CD repo (256x256 tiles, threshold 0.5, min 50 changed pixels):
- Pairs with real change: 10, caught 10 (recall 100%)
- Alerts that were correct: 10/10 (precision 100%)
- False alarms: 0 of 1 no-change pair (0%)
- Pixel level: precision 0.908, recall 0.947, F1 0.927, IoU 0.864
- Caveat: a very small, favourable demo set with only one no-change pair; expect lower numbers on larger data (e.g. Friend 1's pairs). Rerun scripts/evaluate_change.py on those when available.

### Notes
- The change model detects new buildings (LEVIR-CD). The solar/pool alert combines it with the rooftop detector in scripts/predict_example.py (new_addon_alert).
